
package programaE.service;



import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

@Path("/programaE")
public class messageService {
   
    
    @POST
    public void imprimirNotificacion(String ss)
            
    {   
    String a = "***************************************************************";
    System.out.println("\033[33m"+a+a);
    System.out.println("\033[34m"+a+a);
    System.out.println("\033[31m"+a+a);
    System.out.println(ss);
    System.out.println("\033[31m"+a+a);
    System.out.println("\033[34m"+a+a);
    System.out.println("\033[33m"+a+a);
    }
    
    @GET
    public void obtener(){
         //System.out.println("*********************");
        
    }
}
