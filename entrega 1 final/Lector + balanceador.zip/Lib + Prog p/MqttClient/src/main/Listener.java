
package main;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
public class Listener implements MqttCallback {
	
    /** The broker url. */
    private static final String brokerUrl = "tcp://172.24.42.100:8083";

    /** The client id. */
    private static final String clientId = "Consumidor";

    /** The topic. */
    private static final String topic = "#";
    private static int cont;
    private static int pruebaS;
    private static boolean estadoS1;
    private static boolean estadoS2;

    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
    	pruebaS =0;
    	cont =1;
    	estadoS1=true;
    	estadoS2=true;
        new Listener().subscribe(topic);
    }

    /**
     * Subscribe.
     *
     * @param topic
     *            the topic
     */
    public void subscribe(String topic) {

        MemoryPersistence persistence = new MemoryPersistence();

        try {

            MqttClient sampleClient = new MqttClient(brokerUrl, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);

            System.out.println("checking");

            System.out.println("Mqtt Connecting to broker: " + brokerUrl);
            sampleClient.connect(connOpts);
            System.out.println("Mqtt Connected");

            sampleClient.setCallback(this);
            sampleClient.subscribe(topic);

            System.out.println("Subscribed");
            System.out.println("Listening");

        } catch (MqttException me) {

            System.out.println("Mqtt reason " + me.getReasonCode());
            System.out.println("Mqtt msg " + me.getMessage());
            System.out.println("Mqtt loc " + me.getLocalizedMessage());
            System.out.println("Mqtt cause " + me.getCause());
            System.out.println("Mqtt excep " + me);
        }
    }

    
    public void connectionLost(Throwable arg0) {
    	System.out.println("Conexion perdida");
    	arg0.printStackTrace();

    }

    public void deliveryComplete(IMqttDeliveryToken arg0) {

    }
    
    public void messageArrived(String topic, MqttMessage message) throws Exception {

        System.out.println("Mqtt topic : " + topic);
        System.out.println("Mqtt msg : " + message.toString());
        String correoR = topic.split("/")[3]+"@correo.com.co";
        String asunto = "NOTIFICACION ALARMA";
        String mensaje= message.toString();
        String mensaje2 = mensaje.split(":\"")[2].split("\"")[0];
        String correoD = correoR;
        String pais = topic.split("/")[0];
        String ciudad = topic.split("/")[1];
        String residencia = topic.split("/")[2];
        String inmueble = topic.split("/")[3];
        String idDisp = topic.split("/")[4];
        
        String peticion = "{\"cr\":\""+ correoR+"\", \"cd\":\"" +correoD+"\", \"asunto\":\""+asunto +"\", \"cuerpo\":\""+mensaje2+"\",\"pais\":\""+pais+"\",\"ciudad\":\""+ciudad 
        		+"\",\"residencia\":\""+residencia+"\", \"inmueble\":\""+inmueble+"\", \"idDisp\":\""+idDisp+"\"}";
        String peticion2 = "{\"correoR\":\""+ correoR+"\", \"correoD\":\""+correoD+"\", \"asunto\":\""+asunto +"\", \"mensaje\":\""+mensaje+"\""+"}";
        URL url2 = null;
        
      
      try {
    	if(pruebaS==500)
      	{
      		estadoS1 = true;
      		estadoS2 = true;
      		pruebaS=0;
      	}
    	if(pruebaS>0)
    	{
        pruebaS = pruebaS+1;
    	} 
    	  if(cont==1&&estadoS1==true||estadoS2==false)
    	  {
    		System.out.println("Estado s1:"+estadoS1+" estado S2:"+estadoS2);
    		System.out.println("Servidor:1");
    		cont =2;
            url2 = new URL("http://172.24.42.22:8080/programaP");
    	  }
    	  else if(estadoS2==true)
    	  {
    		  System.out.println("Estado s1:"+estadoS1+" estado s2:"+estadoS2);
    		  System.out.println("Servidor:2");
    		  cont =1;
    		  url2 = new URL("http://172.24.42.69:8080/programaP");
    	  }
          HttpURLConnection con2 = (HttpURLConnection) url2.openConnection();
          con2.setRequestMethod("POST");
   
          con2.setRequestProperty("Content-Type", "application/json");
          con2.setDoOutput(true);

          OutputStream os = con2.getOutputStream();
          
          System.out.println("Peticion :" + peticion);
          System.out.println("PET:"+pruebaS);
          os.write(peticion.getBytes());
          os.flush();
          os.close();

          int responseCode = con2.getResponseCode();

          System.out.println("Response Code :" + responseCode);

          if (responseCode == 200) {
            System.out.println("Created alarmy successfully.");
          } else {
            System.out.println("Created alarmy failed.");
            System.out.println(responseCode);
          }
        } catch (Exception e) {
        	System.out.println("El servidor no esta en funcionamiento pero se envio la peticion a otro servidor");
        	pruebaS = 1;
        	System.out.println("PruebaS:"+pruebaS);
        	if(url2==null)
        	{
        		
        	}
        	else if(url2.toString().equals("http://172.24.42.22:8080/programaP"))
        	{
        		estadoS1=false;
        		System.out.println("Estado s1:"+estadoS1+" Estado s2:"+estadoS2);
        		url2 = new URL("http://172.24.42.69:8080/programaP");
        		HttpURLConnection con2 = (HttpURLConnection) url2.openConnection();
                
                con2.setRequestMethod("POST");

            
                con2.setRequestProperty("Content-Type", "application/json");
                con2.setDoOutput(true);

                OutputStream os = con2.getOutputStream();
                
                System.out.println("Peticion :" + peticion);
                System.out.println("PruebaS:"+pruebaS);
                os.write(peticion.getBytes());
                os.flush();
                os.close();
        		
        	}
        	else if(url2.toString().equals("http://172.24.42.69:8080/programaP"))
        	{
        		estadoS2=false;
        		System.out.println("Estado s1:"+estadoS1+" estado s2:"+estadoS2);
        		url2 = new URL("http://172.24.42.22:8080/programaP");
        		HttpURLConnection con2 = (HttpURLConnection) url2.openConnection();
                
                con2.setRequestMethod("POST");

            
                con2.setRequestProperty("Content-Type", "application/json");
                con2.setDoOutput(true);

                OutputStream os = con2.getOutputStream();
                
                System.out.println("Peticion :" + peticion);
                System.out.println("Contador:"+cont);
                os.write(peticion.getBytes());
                os.flush();
                os.close();
        	}
        	
        }
      
        try {
            URL url = new URL("http://172.24.42.100:8080/programaE");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
           
            con.setRequestMethod("POST");

          
            con.setRequestProperty("Content-Type", "text/plain");
            con.setDoOutput(true);

            OutputStream os = con.getOutputStream();
           
            
            os.write(peticion2.getBytes());
            os.flush();
            os.close();

            int responseCode = con.getResponseCode();


            if (responseCode == 200) {
              System.out.println("Se envi� el mensaje");
            } else {
              System.out.println("");
            }
          } catch (Exception e) {
        	  System.out.println("ERROR EN ENVIO A CORREO");
          }


        
        
        
         
     
        
    }

}